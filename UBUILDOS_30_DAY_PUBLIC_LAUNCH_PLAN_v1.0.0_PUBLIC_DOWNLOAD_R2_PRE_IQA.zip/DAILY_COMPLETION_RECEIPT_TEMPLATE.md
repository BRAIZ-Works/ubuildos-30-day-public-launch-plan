# Daily Completion Receipt™ Template

- Day / build:
- Exact public subject:
- Public URL:
- What was promised:
- What was completed:
- Measured time (or NOT MEASURED):
- QA / verification performed:
- Known material defects: NONE / list
- Claims supported:
- Non-claims / limits:
- Live readback: PASS / FAIL
- Lesson:
- Next day:

Rule: if live readback fails, the day remains open.
