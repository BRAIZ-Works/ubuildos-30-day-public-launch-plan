# Quickstart

1. Read `UBUILDOS_30_DAY_PUBLIC_LAUNCH_PLAN_v1.0.0.pdf`.
2. Open `UBUILDOS_30_DAY_PUBLIC_LAUNCH_WORKBOOK_v1.0.0.xlsx`.
3. Fill in the START_HERE sheet.
4. In 30_DAY_PLAN, keep the public purpose for each day and replace the example with proof from your own business.
5. Use DAILY_RECEIPT after each publication.
6. Use METRICS only for values you actually measured.
7. Run WEEKLY_REVIEW before changing the next week.

Rule: publish what you can prove; label what you estimate; disclose what you do not know.
